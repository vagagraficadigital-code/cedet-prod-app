
import { createClient } from '@supabase/supabase-js'
const url = import.meta.env.VITE_SUPABASE_URL || localStorage.getItem('supabase.url') || ''
const key = import.meta.env.VITE_SUPABASE_ANON_KEY || localStorage.getItem('supabase.key') || ''
export default { client: (url && key) ? createClient(url, key) : null, url, key }
