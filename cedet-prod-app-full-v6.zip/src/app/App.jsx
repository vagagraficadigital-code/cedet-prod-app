// App.jsx atualizado com fallback priority -> created_at
